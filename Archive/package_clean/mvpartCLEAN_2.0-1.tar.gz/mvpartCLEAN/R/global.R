
#' 
#' @useDynLib mvpartCLEAN, .registration = TRUE
#' 

## Global variable definition:
".noGenerics" <- TRUE
".packageName" <- "mvpart"
globalVariables(c(".noGenerics",".packageName"))
