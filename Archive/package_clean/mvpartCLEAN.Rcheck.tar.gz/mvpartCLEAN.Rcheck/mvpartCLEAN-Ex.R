pkgname <- "mvpartCLEAN"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('mvpartCLEAN')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
base::assign(".old_wd", base::getwd(), pos = 'CheckExEnv')
cleanEx()
nameEx("car.test.frame")
### * car.test.frame

flush(stderr()); flush(stdout())

### Name: car.test.frame
### Title: Automobile Data from 'Consumer Reports' 1990
### Aliases: car.test.frame
### Keywords: datasets

### ** Examples

## Load and print the data frame:
data("car.test.frame")
car.test.frame




cleanEx()
nameEx("cmds.diss")
### * cmds.diss

flush(stderr()); flush(stdout())

### Name: cmds.diss
### Title: Classical Scaling of Dissimilarity Measures
### Aliases: cmds.diss
### Keywords: multivariate

### ** Examples

data(spider)
dist.vecs <- cmds.diss(spider)




cleanEx()
nameEx("gdist")
### * gdist

flush(stderr()); flush(stdout())

### Name: gdist
### Title: Dissimilarity Measures
### Aliases: gdist
### Keywords: multivariate

### ** Examples

data(spider)
spider.dist <- gdist(spider[,1L:12L])




cleanEx()
nameEx("kyphosis")
### * kyphosis

flush(stderr()); flush(stdout())

### Name: kyphosis
### Title: Data on Children who have had Corrective Spinal Surgery
### Aliases: kyphosis
### Keywords: datasets

### ** Examples

## Load and print the data frame:
data("kyphosis")
kyphosis




cleanEx()
nameEx("makeform")
### * makeform

flush(stderr()); flush(stdout())

### Name: makeform
### Title: Formula Constructor
### Aliases: makeform
### Keywords: models

### ** Examples

data(spider)
makeform(spider,1,13:18)
# arct.lute ~ water + sand + moss + reft + twigs + herbs

makeform(spider,1:12,13:18)
# cbind(arct.lute, pard.lugu, zora.spin, pard.nigr, pard.pull, 
# aulo.albi, troc.terr, alop.cune, pard.mont, alop.acce, alop.fabr, 
# arct.peri) ~ water + sand + moss + reft + twigs + herbs

makeform(spider,1:12,13:15,16:18)
# cbind(arct.lute, pard.lugu, zora.spin, pard.nigr, pard.pull, 
# aulo.albi, troc.terr, alop.cune, pard.mont, alop.acce, alop.fabr, 
# arct.peri) ~ water + sand + moss + Condition(reft + twigs + herbs)

makeform(spider,1:12,13:15,maxy=6)
# as.matrix(spider[, 1:12]) ~ water + sand + moss

makeform(spider,1:3,13:15,FUN=sqrt)
# sqrt(cbind(arct.lute, pard.lugu, zora.spin)) ~ water + sand + moss

makeform(spider,1:3,13:15,FUN=sqrt,extra="I(water^2)+")
# sqrt(cbind(arct.lute, pard.lugu, zora.spin)) ~ I(water^2) + water + 
# sand + moss




cleanEx()
nameEx("mvpart")
### * mvpart

flush(stderr()); flush(stdout())

### Name: mvpart
### Title: Recursive Partitioning and Regression Trees
### Aliases: mvpart
### Keywords: tree

### ** Examples

data(spider)
mvpart(data.matrix(spider[,1:12])~herbs+reft+moss+sand+twigs+
         water,spider)       # defaults
mvpart(data.matrix(spider[,1:12])~herbs+reft+moss+sand+twigs+
         water,spider,xv="p")  # pick the tree size
# pick cv size and do PCA
fit <- mvpart(data.matrix(spider[,1:12])~herbs+reft+moss+sand+
                twigs+water,spider,xv="1se",pca=TRUE)
rpart.pca(fit,interact=TRUE,wgt.ave=TRUE)
# interactive PCA plot of saved multivariate tree




cleanEx()
nameEx("path.rpart")
### * path.rpart

flush(stderr()); flush(stdout())

### Name: path.rpart
### Title: Follow Paths to Selected Nodes of an Rpart Object
### Aliases: path.rpart
### Keywords: tree

### ** Examples

data(kyphosis)
fit <- rpart(Kyphosis ~ Age + Number + Start, data = kyphosis)
path.rpart(fit, node=c(11, 22))




cleanEx()
nameEx("printcp")
### * printcp

flush(stderr()); flush(stdout())

### Name: printcp
### Title: Displays CP table for Fitted Rpart Object
### Aliases: printcp
### Keywords: tree

### ** Examples

data(car.test.frame)
z.auto <- rpart(Mileage ~ Weight, car.test.frame)
printcp(z.auto)
## Not run: 
##D   Regression tree:
##D     rpart(formula = Mileage ~ Weight, data = car.test.frame)
##D   
##D   Variables actually used in tree construction:
##D     [1] Weight
##D   
##D   Root node error: 1354.6/60 = 22.576
##D   
##D   CP nsplit rel error  xerror     xstd 
##D   1 0.595349      0   1.00000 1.03436 0.178526
##D   2 0.134528      1   0.40465 0.60508 0.105217
##D   3 0.012828      2   0.27012 0.45153 0.083330
##D   4 0.010000      3   0.25729 0.44826 0.076998
## End(Not run)




cleanEx()
nameEx("rpart-class")
### * rpart-class

flush(stderr()); flush(stdout())

### Name: rpart-class
### Title: Class and Methods for Recursive Partitioning and Regression
###   Trees
### Aliases: rpart-class labels.rpart print.rpart prune.rpart predict.rpart
###   residuals.rpart rsq.rpart plot.rpart summary.rpart text.rpart
###   meanvar.rpart

### ** Examples

## print.rpart

data(car.test.frame)
z.auto <- rpart(Mileage ~ Weight, car.test.frame)
z.auto

## plot.rpart
data(car.test.frame)
fit <- rpart(Price ~ Mileage + Type + Country, car.test.frame)
plot(fit, compress=TRUE)

## summary.rpart
data(car.test.frame)
z.auto <- rpart(Mileage ~ Weight, car.test.frame)
summary(z.auto)

## predict.rpart:
data(car.test.frame)
z.auto <- rpart(Mileage ~ Weight, car.test.frame)
predict(z.auto)

data(kyphosis)
fit <- rpart(Kyphosis ~ Age + Number + Start, data=kyphosis)
predict(fit, type="prob")   # class probabilities (default)
predict(fit, type="vector") # level numbers
predict(fit, type="class")  # factor
predict(fit, type="matrix") # level number, class frequencies, probabilities

data(iris)
sub <- c(sample(1:50, 25), sample(51:100, 25), sample(101:150, 25))
fit <- rpart(Species ~ ., data=iris, subset=sub)
fit
table(predict(fit, iris[-sub,], type="class"), iris[-sub, "Species"])

## residuals.rpart:
data(solder)
fit <- rpart(skips ~ Opening + Solder + Mask + PadType + Panel,
             data = solder, method='anova')
summary(residuals(fit))
plot(predict(fit),residuals(fit))

# example code
data(car.test.frame)
z.auto <- rpart(Mileage ~ Weight, car.test.frame)
rsq(z.auto)

## text.rpart
data(car.test.frame)
z.auto <- rpart(Mileage ~ Weight, car.test.frame)
plot(z.auto)
text(z.auto, use.n=TRUE, all=TRUE)

## meanvar.rpart
data(car.test.frame)
z.auto <- rpart(Mileage ~ Weight, car.test.frame)
meanvar(z.auto, log='xy')




cleanEx()
nameEx("rpart")
### * rpart

flush(stderr()); flush(stdout())

### Name: rpart
### Title: Recursive Partitioning and Regression Trees
### Aliases: rpart rpartcallback
### Keywords: multivariate

### ** Examples

data(car.test.frame)
z.auto <- rpart(Mileage ~ Weight, car.test.frame)
data(spider)
fit1 <- rpart(data.matrix(spider[,1:12])~water+twigs+reft+herbs+
                moss+sand,spider,method="mrt")
fit2 <- rpart(data.matrix(spider[,1:12])~water+twigs+reft+herbs+
                moss+sand,spider,method="mrt",dissim="man")
fit3 <- rpart(gdist(spider[,1:12],meth="bray",full=TRUE,sq=TRUE)
              ~water+twigs+reft+herbs+moss+sand,spider,method="dist")




cleanEx()
nameEx("rpart.pca")
### * rpart.pca

flush(stderr()); flush(stdout())

### Name: rpart.pca
### Title: Principle Components Plot of a Multivariate Rpart Object
### Aliases: rpart.pca
### Keywords: tree

### ** Examples

data(spider)
fit <- mvpart(data.matrix(spider[,1:12])~herbs+reft+moss+sand+twigs+water,spider)
rpart.pca(fit)
rpart.pca(fit, wgt.ave=TRUE, interact=TRUE)




cleanEx()
nameEx("scaler")
### * scaler

flush(stderr()); flush(stdout())

### Name: scaler
### Title: Row and Column Scaling of a Data Matrix
### Aliases: scaler
### Keywords: manip multivariate

### ** Examples

data(spider)
spid.data <- scaler(spider, col = "max", row="mean1")




cleanEx()
nameEx("solder")
### * solder

flush(stderr()); flush(stdout())

### Name: solder
### Title: Soldering of Components on Printed-Circuit Boards
### Aliases: solder
### Keywords: datasets

### ** Examples

## Load and print the data frame:
data("solder")
solder




cleanEx()
nameEx("spider")
### * spider

flush(stderr()); flush(stdout())

### Name: spider
### Title: Spider Data
### Aliases: spider
### Keywords: spider

### ** Examples

## Load and print the data frame:
data("spider")
spider




cleanEx()
nameEx("trclcomp")
### * trclcomp

flush(stderr()); flush(stdout())

### Name: trclcomp
### Title: Tree-Clustering Comparison
### Aliases: trclcomp
### Keywords: multivariate

### ** Examples

data(spider)
fit <- mvpart(data.matrix(spider[,1:12])~herbs+reft+moss+sand+twigs+water,
              spider)
trclcomp(fit)




cleanEx()
nameEx("xdiss")
### * xdiss

flush(stderr()); flush(stdout())

### Name: xdiss
### Title: Extendend Dissimilarity Measures
### Aliases: xdiss
### Keywords: multivariate

### ** Examples

data(spider)
spider.dist <- xdiss(spider[,1L:12L])




cleanEx()
nameEx("xpred.rpart")
### * xpred.rpart

flush(stderr()); flush(stdout())

### Name: xpred.rpart
### Title: Return Cross-Validated Predictions
### Aliases: xpred.rpart
### Keywords: tree

### ** Examples

data(car.test.frame)
fit <- rpart(Mileage ~ Weight, car.test.frame)
xmat <- xpred.rpart(fit)
xerr <- (xmat - car.test.frame$Mileage)^2
apply(xerr, 2, sum)   # cross-validated error estimate

# approx same result as rel. error from printcp(fit)
apply(xerr, 2, sum)/var(car.test.frame$Mileage)
printcp(fit)




### * <FOOTER>
###
cleanEx()
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
